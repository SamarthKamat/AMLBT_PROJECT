# UDI 2.0 — executed test report

This report records tests that were **executed**, not only defined.

| Item | Value |
|---|---|
| Date (UTC) | 2026-11-18 |
| Environment | Linux, Python 3.13.18, packages exactly as pinned in `backend/requirements.txt` (venv); Node 22, npm 10 |
| Command | `cd backend && python -m pytest -q --junitxml=../evaluation/results/pytest_junit.xml` |
| Result | **178 passed, 0 failed, 0 errors, 0 skipped** in 214.8 s |
| Machine-readable log | `evaluation/results/pytest_junit.xml` |

## Executed tests per module
| Module | Executed | What it covers |
|---|---:|---|
| `test_loading_profiling.py` | 22 | CSV/XLSX loading, delimiters, encodings, header detection, type coercion, role inference |
| `test_validation.py` | 17 | invalid columns rejected (never substituted), types, filters, sufficiency, clarification |
| `test_operations.py` | 21 | the deterministic operations (summary, current state, groups, trend, correlation, anomalies) |
| `test_ml.py` | 12 | dynamic model selection, metrics, caching, leakage/weak-model warnings, scenarios |
| `test_forecast.py` | 8 | rolling-origin backtest, baselines, horizon limits, frequencies |
| `test_reference_models.py` | 12 | Phase 1 reference models reproduce stored metrics |
| `test_explainer.py` | 3 | Gemini wording rejected if it contains numbers not in the verified result |
| `test_gemini_client.py` | 23 | Gemini error mapping, strict JSON, schema, **source scan for exec/eval/subprocess/`__import__`**, no hard-coded key/model |
| `test_api_e2e.py` | 24 | API end to end: **all 18 operations routed on one dataset**, follow-ups, clarification, errors, Gemini-only mode, **auto mode falling back to the local planner**, new chat, sessions |
| `test_phase2.py` | 36 | semantics, relationships (hierarchy + formula detection), data quality + cleaning, **SHAP exactness on a linear model**, one-standard-error rule, ETS/ARIMA + 95% band, no target substitution in forecasting, root-cause decomposition adds up, pivot/query/segment/EDA, reports + PDF/Excel export, local planner routing (10 questions), Phase 2 endpoints, **persistence across restart**, **auth/ownership**, rate limiting, **user exclusions ("without X") and the dominant-feature leakage warning**, **forecast divergence guard**, near-miss variables refused rather than substituted ("volunteer age", "garbage trucks", "employee salary" when only PercentSalaryHike exists), "over time" never linked to an OverTime column, head nouns before generic tails ("faculty" → Faculty_Count) |

## Phase 1 vs Phase 2 reconciliation
Phase 1's paper stated "112 test functions defined"; its test report recorded 12 executed tests. Executing the Phase 1 suite here gave **141 passing test cases** (112 functions, several parametrised). Phase 2 adds 37 cases (36 in `test_phase2.py`, 1 in `test_api_e2e.py`) for **178 executed, all passing**.

## Other verification
| Check | Result |
|---|---|
| Frontend production build (`npm run build`) | passed (Vite 5.4.11, 2,390 modules) — Phase 1 could not certify this |
| Browser end-to-end (Playwright, headless Chromium) | upload of a bundled dataset, 8 chat questions, Relationships, EDA, Data quality (cleaning + before/after), Reports (sales report) and History tabs all rendered; the only console error was the intended 422 for a missing column |
| Held-out NL benchmark (local planner) | v1 run 1 `benchmark_local_heldout_run1.json` (88.5% end-to-end), v1 same-code `benchmark_v1_local_current.json` (96.2%), **v2 frozen held-out** `benchmark_v2_local_heldout.json` (87.9%, CI 80.0–92.9); comparison runs `benchmark_v{1,2}_{keyword,local_exact}.json`; McNemar tests `paired_tests.json`; per-question logs for all; **v3 frozen held-out, public data only** (`benchmark_questions_v3.jsonl` + `.sha256`, 100 q): local 73.0%, exact linking 74.0%, keyword 47.0%, Gemini planner 87.0% (`benchmark_v3_*.json`); plain-LLM baseline `llm_direct_v3.json`; v2 re-run after the near-miss fix (not held-out) `benchmark_v2_local_postfix.json` 89/99, refusals 11/11 |
| Gemini-mode benchmark | provided (`python evaluation/run_benchmark.py --planner gemini`) but **not executed** in this environment (no API key) |
| `run_windows.bat` | not executed here (Linux environment); `run_unix.sh` steps were executed individually |
