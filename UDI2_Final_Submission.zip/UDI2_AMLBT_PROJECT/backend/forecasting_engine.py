"""forecast: time-aware forecasting with rolling-origin backtesting (observations are never shuffled).

Candidates are scored on the last blocks of the real series (expanding window); the winner is refit on all history.
Naive baselines are always included so the report says honestly whether a model adds skill.
"""
from __future__ import annotations
import warnings
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

try:                                                     # statsmodels is optional: ETS / ARIMA candidates
    from statsmodels.tsa.holtwinters import ExponentialSmoothing
    from statsmodels.tsa.statespace.sarimax import SARIMAX
    HAVE_SM = True
except Exception:                                        # pragma: no cover
    HAVE_SM = False

from context import ExecContext
from diagnostics_engine import FREQ_ADJ, FREQ_NAME, PERIOD_ALIAS, aggregate_series, native_frequency, period_label
from errors import UDIError
from result_formatter import fmt_num, make_result, records
from validator import ValidatedPlan

MIN_PERIODS = 24
MIN_TRAIN = 12
MAX_MISSING_FRACTION = 0.2
SEASON = {"H": 24, "D": 7, "W": 52, "M": 12, "Q": 4, "Y": 1}
DEFAULT_HORIZON = {"H": 24, "D": 14, "W": 8, "M": 6, "Q": 4, "Y": 2}


# ----------------------------------------------------------------------------- candidate forecasters
def _seasonal_m(freq: str, n: int) -> int:
    m = SEASON[freq]
    return m if (m >= 2 and n >= 2 * m) else 0


def _naive(y, h, m):
    return np.repeat(y[-1], h)


def _seasonal_naive(y, h, m):
    return np.array([y[len(y) - m + (i % m)] for i in range(h)])


def _moving_average(y, h, m):
    k = m if m >= 2 else 3
    return np.repeat(float(np.mean(y[-k:])), h)


def _linear_trend(y, h, m):
    n = len(y)
    t = np.arange(n).reshape(-1, 1)
    lr = LinearRegression().fit(t, y)
    resid = y - lr.predict(t)
    seas = np.zeros(m) if m else None
    if m:
        for k in range(m):
            seas[k] = resid[k::m].mean()
    tf = np.arange(n, n + h)
    out = lr.predict(tf.reshape(-1, 1))
    if m:
        out = out + np.array([seas[t_ % m] for t_ in tf])
    return out


def _lags(n: int, m: int) -> List[int]:
    lags = [1, 2, 3]
    if m > 3 and n - m >= MIN_TRAIN:
        lags.append(m)
    return sorted(set(lags))


def _make_ar(model_factory: Callable[[], Any]):
    def fn(y, h, m):
        n = len(y)
        lags = _lags(n, m)
        L = max(lags)
        X = np.array([[y[t - l] for l in lags] + [t] for t in range(L, n)], dtype=float)
        Y = y[L:]
        mdl = model_factory()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            mdl.fit(X, Y)
        hist = list(y)
        out = []
        for _ in range(h):
            t = len(hist)
            x = np.array([[hist[t - l] for l in lags] + [t]], dtype=float)
            v = float(mdl.predict(x)[0])
            hist.append(v)
            out.append(v)
        return np.array(out)
    return fn


def _ets(y, h, m):
    seasonal = "add" if (m and len(y) >= 2 * m) else None
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        fit = ExponentialSmoothing(np.asarray(y, float), trend="add", damped_trend=True, seasonal=seasonal,
                                   seasonal_periods=m if seasonal else None, initialization_method="estimated").fit(optimized=True)
    return np.asarray(fit.forecast(h), float)


def _arima(y, h, m):
    """Small AIC search over ARIMA orders; seasonal (1,0,1,m) term when the history covers >= 3 seasons."""
    y = np.asarray(y, float)
    seasonal = (1, 0, 1, m) if (m and 2 <= m <= 24 and len(y) >= 3 * m) else (0, 0, 0, 0)
    best, best_aic = None, np.inf
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for order in ((1, 1, 1), (0, 1, 1), (2, 1, 1)):
            try:
                res = SARIMAX(y, order=order, seasonal_order=seasonal, enforce_stationarity=False, enforce_invertibility=False).fit(disp=False, maxiter=60)
                if np.isfinite(res.aic) and res.aic < best_aic:
                    best, best_aic = res, res.aic
            except Exception:
                continue
    if best is None:
        raise ValueError("no ARIMA order converged")
    return np.asarray(best.forecast(h), float)


def _candidates(m: int, n: int) -> Dict[str, Callable]:
    c: Dict[str, Callable] = {"Naive (last value)": _naive}
    if m:
        c["Seasonal naive"] = _seasonal_naive
    c["Moving average"] = _moving_average
    c["Linear trend" + (" + seasonal profile" if m else "")] = _linear_trend
    c["Autoregressive Ridge (lags + trend)"] = _make_ar(lambda: make_pipeline(StandardScaler(), Ridge(alpha=1.0)))
    c["Random Forest (lags)"] = _make_ar(lambda: RandomForestRegressor(n_estimators=200, min_samples_leaf=2, n_jobs=-1, random_state=42))
    c["Gradient Boosting (lags)"] = _make_ar(lambda: GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.06, random_state=42))
    if HAVE_SM and n >= MIN_PERIODS:
        c["Holt-Winters ETS (damped trend" + (" + seasonal)" if m else ")")] = _ets
        if n <= 800:
            c["ARIMA / SARIMA (AIC-selected)" if m else "ARIMA (AIC-selected)"] = _arima
    return c


def choose_frequency(d: pd.DataFrame, tc: str, tgt: str, agg: str, requested: Optional[str]) -> Tuple[str, Optional[str]]:
    """Requested frequency, else the native one coarsened until the series is dense enough to forecast
    (<= 20% empty periods) while keeping at least MIN_PERIODS periods. Returns (freq, note)."""
    native = native_frequency(d[tc])
    if requested:
        return requested, None
    order = ["H", "D", "W", "M", "Q", "Y"]
    for f in order[order.index(native):]:
        s = aggregate_series(d, tc, tgt, agg, f)
        if len(s) and s.isna().mean() <= MAX_MISSING_FRACTION and s.notna().sum() >= MIN_PERIODS:
            if f != native:
                return f, (f"The data has gaps at its native {FREQ_ADJ[native]} spacing, so it was aggregated to {FREQ_ADJ[f]} periods "
                           f"({int(s.notna().sum())} periods, {s.isna().mean():.0%} empty).")
            return f, None
    return native, None


def _interval_sigmas(errors: List[np.ndarray], horizon: int, h_bt: int) -> np.ndarray:
    """Horizon-dependent error scale from backtest errors: RMS error at each step ahead (made non-decreasing),
    extrapolated with sqrt(step) beyond the backtest block."""
    E = np.vstack([e[:h_bt] for e in errors if len(e) >= h_bt]) if errors else np.zeros((0, h_bt))
    if E.size == 0:
        return np.full(horizon, np.nan)
    step = np.sqrt(np.mean(E ** 2, axis=0))
    pooled = float(np.sqrt(np.mean(E ** 2)))
    step = np.maximum.accumulate(np.maximum(step, 0.5 * pooled))         # few folds: never narrower than half the pooled error
    out = np.empty(horizon)
    for i in range(horizon):
        out[i] = step[i] if i < len(step) else step[-1] * np.sqrt((i + 1) / len(step))
    return out


# ----------------------------------------------------------------------------- engine
def plan_backtest(n_total: int, horizon: int) -> Tuple[int, List[int]]:
    """Expanding-window backtest: consecutive, non-overlapping test blocks taken from the END of the series.
    Each fold trains on y[:cut] and is scored on y[cut:cut+h]; training data always precedes its test block."""
    h_bt = int(min(horizon, max(3, n_total // 8)))
    folds = 3
    while folds > 1 and n_total - folds * h_bt < MIN_TRAIN:
        folds -= 1
    if n_total - folds * h_bt < MIN_TRAIN:
        h_bt = max(1, n_total - MIN_TRAIN)
        folds = 1
    return h_bt, [n_total - h_bt * (folds - k) for k in range(folds)]


def _metrics(actual: np.ndarray, pred: np.ndarray) -> Dict[str, Optional[float]]:
    err = actual - pred
    out = {"MAE": float(np.mean(np.abs(err))), "RMSE": float(np.sqrt(np.mean(err ** 2))), "MAPE": None}
    if np.all(np.abs(actual) > 1e-9):
        out["MAPE"] = float(np.mean(np.abs(err / actual)) * 100)
    return out


def forecast(vp: ValidatedPlan, ctx: ExecContext) -> Dict[str, Any]:
    p, d, tc, tgt = vp.plan, vp.data, vp.time_column, vp.plan.target_column
    agg = p.aggregation or "mean"
    freq, freq_note = choose_frequency(d, tc, tgt, agg, p.frequency)
    unit = FREQ_NAME[freq]
    s = aggregate_series(d, tc, tgt, agg, freq)
    have = int(s.notna().sum())
    gaps = int(s.isna().sum())
    if have < MIN_PERIODS:
        finer = {"Y": "Q", "Q": "M", "M": "W", "W": "D"}.get(freq)
        hint = ""
        if finer:
            alt = aggregate_series(d, tc, tgt, agg, finer)
            if alt.notna().sum() >= MIN_PERIODS:
                hint = f" The data would support a forecast at {FREQ_ADJ[finer]} resolution ({int(alt.notna().sum())} periods)."
        raise UDIError("INSUFFICIENT_DATA", f"Only {have} {unit}(s) of history are available for '{tgt}'; forecasting needs at least {MIN_PERIODS} distinct periods.{hint}",
                       details={"periods": have, "frequency": freq, "required": MIN_PERIODS})
    if len(s) and gaps / len(s) > MAX_MISSING_FRACTION:
        raise UDIError("INSUFFICIENT_DATA", f"{gaps} of {len(s)} {unit}s have no data (over {MAX_MISSING_FRACTION:.0%}); the series is too sparse to forecast at {FREQ_ADJ[freq]} resolution.")
    n_total = len(s)
    horizon = p.forecast_horizon or DEFAULT_HORIZON[freq]
    if horizon > n_total // 3:
        raise UDIError("INSUFFICIENT_DATA", f"A {horizon}-{unit} horizon is too long for {n_total} {unit}s of history; at most {n_total // 3} {unit}s can be forecast reliably (one third of the history).",
                       details={"max_horizon": n_total // 3})
    y = s.interpolate(limit_direction="both").to_numpy(dtype=float)
    m = _seasonal_m(freq, n_total)
    cands = _candidates(m, n_total)

    # ---- rolling-origin backtest on the last blocks
    h_bt, cuts = plan_backtest(n_total, horizon)
    folds = len(cuts)
    scores: List[Dict[str, Any]] = []
    errors_pool: Dict[str, List[np.ndarray]] = {}
    for name, fn in cands.items():
        fold_m, errs, failed = [], [], None
        for cut in cuts:
            try:
                pred = fn(y[:cut], h_bt, _seasonal_m(freq, cut))
                actual = y[cut:cut + h_bt]
                fold_m.append(_metrics(actual, pred))
                errs.append(actual - pred)
            except Exception as exc:        # a candidate that cannot fit this fold is reported, not hidden
                failed = str(exc)[:120]
                break
        if failed or not fold_m:
            scores.append({"model": name, "error": failed or "no folds"})
            continue
        mape = [f["MAPE"] for f in fold_m if f["MAPE"] is not None]
        scores.append({"model": name, "RMSE": float(np.mean([f["RMSE"] for f in fold_m])), "MAE": float(np.mean([f["MAE"] for f in fold_m])),
                       "MAPE": float(np.mean(mape)) if len(mape) == len(fold_m) else None})
        errors_pool[name] = errs
    ok = sorted([r for r in scores if "error" not in r], key=lambda r: r["RMSE"])
    if not ok:
        raise UDIError("MODEL_TRAINING_ERROR", "No forecasting model could be fitted: " + "; ".join(r.get("error", "") for r in scores)[:300])
    best = ok[0]
    for r in scores:
        r["selected"] = r.get("model") == best["model"]
    scores = sorted(scores, key=lambda r: r.get("RMSE", float("inf")))
    naive = next(r for r in ok if r["model"] == "Naive (last value)") if any(r["model"] == "Naive (last value)" for r in ok) else None
    best_baseline = min((r for r in ok if r["model"] in ("Naive (last value)", "Seasonal naive", "Moving average")), key=lambda r: r["RMSE"], default=None)

    # ---- final fit on all history
    fn = cands[best["model"]]
    fc = np.asarray(fn(y, horizon, m), dtype=float)
    pooled = np.concatenate(errors_pool[best["model"]]) if errors_pool.get(best["model"]) else np.array([best["RMSE"]])
    sigma = float(np.sqrt(np.mean(pooled ** 2)))
    sig_h = _interval_sigmas(errors_pool.get(best["model"], []), horizon, h_bt)
    sig_h = np.where(np.isnan(sig_h), sigma, sig_h)
    last_p = s.index[-1]
    future_idx = pd.period_range(last_p + 1, periods=horizon, freq=PERIOD_ALIAS[freq])
    f_rows = [{"period": period_label(i, freq), "forecast": float(v), "lower_80": float(v - 1.2816 * sh), "upper_80": float(v + 1.2816 * sh),
               "lower_95": float(v - 1.96 * sh), "upper_95": float(v + 1.96 * sh)}
              for i, v, sh in zip(future_idx, fc, sig_h)]
    hist_keep = min(n_total, max(60, horizon * 4))
    hist_rows = [{"period": period_label(i, freq), "actual": None if pd.isna(v) else float(v)} for i, v in zip(s.index[-hist_keep:], s.to_numpy()[-hist_keep:])]
    joined = hist_rows + [{"period": r["period"], "forecast": r["forecast"], "lower": r["lower_80"], "upper": r["upper_80"],
                           "lower95": r["lower_95"], "upper95": r["upper_95"]} for r in f_rows]
    if hist_rows and hist_rows[-1]["actual"] is not None:      # connect the two lines
        a = hist_rows[-1]["actual"]
        joined[len(hist_rows) - 1].update(forecast=a, lower=a, upper=a, lower95=a, upper95=a)
    skill = None
    if best_baseline and best_baseline["RMSE"] > 0:
        skill = (1 - best["RMSE"] / best_baseline["RMSE"]) * 100
    label_measure = f"{agg} of {tgt}" if agg != "mean" else f"average {tgt}"
    summary = (f"Forecast of {label_measure} per {unit} for the next {horizon} {unit}(s): from {fmt_num(fc[0])} ({f_rows[0]['period']}) to {fmt_num(fc[-1])} ({f_rows[-1]['period']}), "
               f"averaging {fmt_num(float(np.mean(fc)))}. Selected model: {best['model']} (rolling backtest RMSE {fmt_num(best['RMSE'])}, MAE {fmt_num(best['MAE'])}"
               + (f", MAPE {best['MAPE']:.1f}%" if best["MAPE"] is not None else "") + ").")
    lim = ["Forecasts assume historical patterns continue; they cannot anticipate events, policy changes or shocks outside the data.",
           f"The 80% and 95% ranges are approximate: they use the size of errors seen at each step ahead in the backtest ({folds} fold(s) of {h_bt} {unit}(s)), widening with the horizon; they are not a formal probability model.",
           "Observations were never shuffled: every backtest forecast uses only data from before its test block."]
    if skill is not None:
        if skill <= 0:
            lim.append(f"The selected model does not beat the best simple baseline ({best_baseline['model']}, RMSE {fmt_num(best_baseline['RMSE'])}); the series may be hard to predict beyond its recent level.")
        else:
            summary += f" That is {skill:.0f}% lower error than the best naive baseline ({best_baseline['model']})."
    if gaps:
        lim.append(f"{gaps} {unit}(s) without data were filled by linear interpolation.")
    assumptions = list(vp.assumptions)
    if freq_note:
        assumptions.append(freq_note)
    elif not p.frequency:
        assumptions.append(f"The series was forecast at its natural {FREQ_ADJ[freq]} resolution.")
    metrics = {"Selected model": best["model"], "Backtest RMSE": best["RMSE"], "Backtest MAE": best["MAE"], "Horizon": f"{horizon} {unit}(s)",
               "History": f"{n_total} {unit}s", "Forecast average": float(np.mean(fc))}
    if best["MAPE"] is not None:
        metrics["Backtest MAPE %"] = best["MAPE"]
    return make_result("forecast", summary, title=f"{tgt} forecast", metrics=metrics, table=f_rows, table_title=f"Forecast for the next {horizon} {unit}(s)",
                       tables={"candidate_models": scores},
                       charts=[{"type": "forecast", "title": f"{tgt}: history and {horizon}-{unit} forecast", "x": "period", "data": joined}],
                       evaluation={"task": "forecast", "selected_model": best["model"], "selection_metric": "rolling-origin backtest RMSE (lower is better)",
                                   "backtest": {"folds": folds, "test_block_periods": h_bt, "min_train_periods": MIN_TRAIN}, "metrics": {k: best[k] for k in ("MAE", "RMSE", "MAPE")},
                                   "baseline": best_baseline, "skill_vs_baseline_%": skill, "candidates": scores, "seasonal_period": m},
                       forecast={"target": tgt, "frequency": freq, "aggregation": agg, "horizon": horizon, "history_periods": n_total, "periods": f_rows,
                                 "interval": "approximate 80% / 95% ranges from step-ahead backtest errors"},
                       limitations=lim, assumptions=assumptions)
